//
//  SVGStyleElement.h
//  SVGPad
//
//  Created by Kevin Stich on 2/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SVGElement.h"

@interface SVGStyleElement : SVGElement

@end
