#import "SVGTextPositioningElement.h"

@interface SVGTextPositioningElement ()
@property(nonatomic,strong,readwrite) SVGLength* /* FIXME: should be SVGAnimatedLengthList */ x;
@property(nonatomic,strong,readwrite) SVGLength* /* FIXME: should be SVGAnimatedLengthList */ y;
@property(nonatomic,strong,readwrite) SVGLength* /* FIXME: should be SVGAnimatedLengthList */ dx;
@property(nonatomic,strong,readwrite) SVGLength* /* FIXME: should be SVGAnimatedLengthList */ dy;
@property(nonatomic,strong,readwrite) SVGLength* /* FIXME: should be SVGAnimatedLengthList */ rotate;
@end
