//
//  SVGElementInstanceList_Internal.h
//  SVGKit-iOS
//
//  Created by adam on 29/09/2012.
//  Copyright (c) 2012 na. All rights reserved.
//

#import "SVGElementInstanceList.h"

@interface SVGElementInstanceList ()

@property(nonatomic,strong) NSMutableArray* internalArray;

@end
