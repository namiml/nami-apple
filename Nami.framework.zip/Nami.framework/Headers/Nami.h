//
//  Nami.h
//  Nami
//
//  Copyright © 2018 Nami ML Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Nami.
FOUNDATION_EXPORT double NamiVersionNumber;

//! Project version string for Nami.
FOUNDATION_EXPORT const unsigned char NamiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Nami/PublicHeader.h>
#import <StoreKit/StoreKit.h>
#import <Nami/Nami-Swift.h>